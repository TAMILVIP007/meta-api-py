# **METAVOID WRAPPER**


_This is a an official Wrapper for matavoid Api. To let users to use api with ease._


## Examples:

To get language translation 


```
from meta_api import META
x = META()
print(x.translate("amma"))
```

To get wallpaper images

```
from meta_api import META
x = META()
print(x.wallpaper("RED ANIME"))
```

<i>Checlout more at <a href="github.com/tamilvip007/meta_api/blob/master/main.py">main.py</a></i>
